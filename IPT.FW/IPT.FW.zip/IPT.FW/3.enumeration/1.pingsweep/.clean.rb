def cleanHosts(myfile,allHosts,myIP)
    ipRegEx = /[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/
    fileIP = myfile.scan(ipRegEx)[0]
    outputfile = File.open("../hosts/" + fileIP  + "_hosts.txt", "w")
    File.readlines(myfile).each do |line|
        if line =~ /Up/
            hostIP = line.scan(ipRegEx)[0]
            #hostIP = line[line.index(" ")+1..line.index(" ",line.index(" ")+1)-1]
            if ! hostIP.eql?  myIP
                allHosts.puts hostIP 
                outputfile.puts hostIP 
            else
                puts "excluding myIP:#{myIP}"
            end
        end
    end
    puts "output written to #{File.dirname outputfile}/#{File.basename outputfile}"
    outputfile.close
end

require 'socket'
myIP = Socket::getaddrinfo(Socket.gethostname,"echo",Socket::AF_INET)[0][3]
allHosts = File.open("../hosts/all_hosts.txt", "w")

Dir.glob("*.gnmap").each do |myfile| 
    cleanHosts(myfile,allHosts,myIP)
end
