#!/bin/bash
grep "21/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/ftp_hosts.txt
grep "22/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/ssh_hosts.txt
grep "23/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/telnet_hosts.txt
grep "25/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/smtp_hosts.txt
grep -e "\ 389/open" -e "636/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/ldap_hosts.txt
grep "80/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/http_80.txt
grep "443/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/http_443.txt
grep "8080/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/http_8080.txt
grep "8443/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/http_8443.txt
grep -e "139/open" -e "445/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/smb_hosts.txt
grep "902/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/esx_hosts.txt
grep "1433/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/mssql_hosts.txt
grep -e "1158/open" -e "1521/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/oracle_hosts.txt
grep "3306/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/mysql_hosts.txt
grep "3389/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/rdp_hosts.txt
grep "5432/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/postgres_hosts.txt
grep -e "5800/open" -e "5900/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/vnc_hosts.txt
grep "6000/open" *.gnmap | cut -d " " -f2 | sort -u > ../hosts/x11_hosts.txt
